<script lang="ts" setup>
import DefaultLayout from './components/DefaultLayout.vue';
</script>

<template>
  <DefaultLayout />
</template>
