import { defineStore } from 'pinia';

export const useStoreName = defineStore('template', {
  state: () => {
    return {};
  },
  getters: {},
  actions: {},
});
