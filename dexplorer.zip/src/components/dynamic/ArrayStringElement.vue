<script lang="ts" setup>
const props = defineProps(['value']);
</script>
<template>
  <span>{{ props.value }}</span>
</template>
