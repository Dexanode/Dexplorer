<script lang="ts" setup>
// router.push(`/${props.chain}/ibc/connection/connection-0`)
</script>
<template>
    <div></div>
</template>
<route>
    {
      meta: {
        i18n: 'ibc',
        order: 9
      }
    }
  </route>