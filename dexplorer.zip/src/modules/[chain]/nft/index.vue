<!-- TODO: there's no mint msg at the moment. not sure how NFT comes from?-->
<script lang="ts" setup>

</script>

<template>
    <div>NFT</div>
</template>
